#include <complex.h>

double norm2(double complex *v, int N);
double real_sprod(double complex *v, double complex *w, int N);
